# <a href="#">Learning Management System</a>
Learning Management System - Android App
## Technologies
- Development Language – Kotlin
- IDE - Android Studio

### Project Description :
This project is about the development of an application which can help students or employers who wants to get certified in Google's Associate Certified Engineer (ACE). They can take practice tests on this certification exam, which helps them to get practiced thoroughly with their preparation.



## **Mobile interfaces view** 
<p align="center">
<img src="https://user-images.githubusercontent.com/89773843/192142047-80684c03-0de8-4b74-a515-0d0ead434a57.png" width="310">

<img src="https://user-images.githubusercontent.com/89773843/192142120-1815cf66-9b97-445a-b669-ace239021272.png" width="310">
</P>
<p align="center">
<img src="https://user-images.githubusercontent.com/89773843/192142157-14ec3fb4-6a44-42d7-a8f9-1b319034a9a3.png" width="310">

<img src="https://user-images.githubusercontent.com/89773843/192142169-2aa79724-5024-4d8f-9741-ffc0501f7541.png" width="310">
</p>
<p align="center">

<img src="https://user-images.githubusercontent.com/89773843/192142174-3bc4a80c-ca28-4c9e-b372-8156457eb678.png" width="310">

</p>


